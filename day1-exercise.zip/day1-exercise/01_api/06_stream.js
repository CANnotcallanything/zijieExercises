const fs=require('fs')
//复制图片

const rs=fs.createReadStream('./1.jpg') //创建一个读的流
const ws=fs.createWriteStream('./2.jpg') //创建一个写的流
rs.pipe(ws)