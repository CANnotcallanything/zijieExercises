module.exports={
    abc:1;
}