//图片切割 合并 js 处理不了 视频压缩 调个底层硬件 POS 封装动态链接库
//Buffer帮助操作二进制数据
const buf1=Buffer.alloc(10) //分配诗歌字节的缓冲区
console.log(buf1)
console.log("hello")

const buf2=Buffer.from('a')
console.log(buf2)

const buf3=Buffer.from('中')//utf-8 utf-16 utf-31
console.log(buf3)

const buf4=Buffer.concat([buf2,buf3])
console.log(buf4,buf4.toString())