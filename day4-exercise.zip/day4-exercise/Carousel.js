initLayout(){

}
autoPalyer(){
    
}